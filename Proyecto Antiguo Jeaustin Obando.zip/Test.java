// Marco Rodriguez Vargas 2022149445
public class Test {
    public static void main(String[] args) {
        // crear los productos herencia
        System.out.println("Creating products...");
        // id, name, price, quantityStock, offer, size, color
        Product p = new Shoes(1, "Nike", 100, 5, 0, "42", "black");
        // id, name, price, quantityStock, offer, size, color
        Product p2 = new Clothes(2, "T-shirt", 50, 20, 0, "M", "white");
        // id, name, price, quantityStock, offer, brand, model
        Product p3 = new Electronics(3, "TV", 500, 5, 0, "Samsung", "Smart TV");
        // id, name, price, quantityStock, offer, platform, genre
        Product p4 = new Games(4, "FIFA 23", 60, 15, 0, "PS4", "Sport");
        System.out.println("");

        // override 
        System.out.println("Por sobrecarga:");
        // puede consultar si hay stock de un producto en una talla especifica
        p.addProduct("42");
        p.addProduct("41");
        System.out.println("");

        // crear los clientes
        LengClient client = new LengClient(1, "David", "Garcia", "Montecillos");
        LengClient client2 = new LengClient(2, "Juan", "Perez", "Belen");
        System.out.println("");

        // imprimir los datos de los clientes
        System.out.println(client.toString());
        System.out.println(client2.toString());
        System.out.println("");

        // crear el carrito de compra con los productos y la cantidad a comprar, una vez ingresado se realiza la compra y se disminuye el stock
        
        System.out.println("Operaciones del carrito de compra del primer cliente:");
        LengShoppingList shopping = new LengShoppingList(new Product[]{p, p2, p3, p4}, client, new int[]{1, 2, 3, 4});
        // imprimir el carrito de compra
        shopping.displayList();
        // imprimir si la lista esta vacia o no, en este caso no esta vacia entonces imprime false
        shopping.isEmpty();
        // contar los productos que hay en la lista de compras
        shopping.countProducts();
        // imprimir el total de la compra
        shopping.totalPurchased();
        System.out.println("");


        System.out.println("Operaciones del carrito de compra del segundo cliente:");
        LengShoppingList shopping2 = new LengShoppingList(new Product[]{}, client2, new int[]{});
        // imprimir si la lista esta vacia o no, en este caso si entonce imprime true
        shopping2.isEmpty();
        // imprimir el carrito de compra, en este caso no hay nada
        shopping2.displayList();
        System.out.println("");

        // agregar stock a un producto en existencia
        System.out.println("Agregando stock a un producto en existencia");
        p.buyProduct(5);
        System.out.println("");

        // herencia de interfaces
        System.out.println("Herencia de interfaces para saber en que zona se encuentra el producto:");
        p.getAreaName();
        p2.getAreaName();
        p3.getAreaName();
        p4.getAreaName();

        System.out.println("Herencia de interfaces para saber quien es el gerente de la zona:");
        p.getManagerName();
        p2.getManagerName();
        p3.getManagerName();
        p4.getManagerName();
    }
}


