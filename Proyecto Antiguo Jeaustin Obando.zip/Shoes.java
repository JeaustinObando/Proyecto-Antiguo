public class Shoes extends Product {
    protected String size;
    protected String color;
    
    public Shoes(int i, String string, int j, int k, int l, String string2, String string3) {
        this.id = i;
        this.name = string;
        this.price = j;
        this.quantityStock = k;
        this.offer = l;
        this.size = string2;
        this.color = string3;
        addProduct();
    }

    void addProduct() {
        System.out.println("Shoes added");
    }

    @Override
    public void addProduct(String information) {
        System.out.println("Su talla es: " + information);
        if (size == information) {
            System.out.println("Hay de esa talla");
        } else {
            System.out.println("No hay de esa talla");
        }
    }

    // agrega n cantidad de stock segun reciba como parametro al stock actual
    void buyProduct(int quantity) {
        this.quantityStock += quantity;
        System.out.println("Se han agregado " + quantity + " unidades");
        System.out.println("El stock actual de " + name + " es: " + quantityStock);
    }

    @Override
    public void getAreaName() {
        System.out.println("Shoes area");
    }

    @Override
    public void getManagerName() {
        System.out.println("Shoes manager: Dylan Mendoza");
    }

    
}