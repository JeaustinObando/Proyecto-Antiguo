public class Electronics extends Product {
    protected String brand;
    protected String model;

    public Electronics(int i, String string, int j, int k, int l, String string2, String string3) {
        this.id = i;
        this.name = string;
        this.price = j;
        this.quantityStock = k;
        this.offer = l;
        this.brand = string2;
        this.model = string3;
        addProduct();
    }

    @Override
    void addProduct() {
        System.out.println("Electronics added");
    }

    // agrega n cantidad de stock segun reciba como parametro al stock actual
    void buyProduct(int quantity) {
        this.quantityStock += quantity;
        System.out.println("Se han agregado " + quantity + " unidades");
        System.out.println("El stock actual de " + name + " es: " + quantityStock);
    }

    @Override
    public void getAreaName() {
        System.out.println("Electronics area");
    }

    @Override
    public void getManagerName() {
        System.out.println("Electronics manager: Thiago Diaz");
    }
        
}

