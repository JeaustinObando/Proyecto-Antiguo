public class LengClient {
    protected int id;
    protected String firstName;
    protected String lastName;
    protected String address;
    protected static String mensajeCliente;

    public static void crearMensaje() {
        mensajeCliente = "New client created";
        System.out.println(mensajeCliente);
    }
    
    public LengClient(int i, String string, String string2, String string3) {
        this.id = i;
        this.firstName = string;
        this.lastName = string2;
        this.address = string3;
        crearMensaje();
    }

    public String toString() {
        String horizontalLine = "+----------------------+\n";
        String idLine = String.format("| Client ID: %-9d |\n", id);
        String firstNameLine = String.format("| First Name: %-7s |\n", firstName);
        String lastNameLine = String.format("| Last Name: %-8s |\n", lastName);
        String addressLine = String.format("| Address: %-11s |\n", address);
        
        return horizontalLine + idLine + horizontalLine + firstNameLine + horizontalLine +
               lastNameLine + horizontalLine + addressLine + horizontalLine;
    }
}
