public class Games extends Product {
    protected String platform;
    protected String genre;

    public Games(int i, String string, int j, int k, int l, String string2, String string3) {
        this.id = i;
        this.name = string;
        this.price = j;
        this.quantityStock = k;
        this.offer = l;
        this.platform = string2;
        this.genre = string3;
        addProduct();
    }

    @Override
    void addProduct() {
        System.out.println("Games added");
    }

    // agrega n cantidad de stock segun reciba como parametro al stock actual
    void buyProduct(int quantity) {
        this.quantityStock += quantity;
        System.out.println("Se han agregado " + quantity + " unidades");
        System.out.println("El stock actual de " + name + " es: " + quantityStock);
    }

    @Override
    public void getAreaName() {
        System.out.println("Gaming area");
    }

    @Override
    public void getManagerName() {
        System.out.println("Gaming manager: Ricardo Hernandez");
    }
}
