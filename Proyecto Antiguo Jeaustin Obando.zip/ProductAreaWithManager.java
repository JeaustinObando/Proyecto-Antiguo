public interface ProductAreaWithManager extends ProductArea{
    public void getManagerName();
}
