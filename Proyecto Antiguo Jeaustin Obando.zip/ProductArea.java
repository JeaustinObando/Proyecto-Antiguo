public interface ProductArea {
    public void getAreaName();
}
