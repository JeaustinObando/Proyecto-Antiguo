public abstract class Product implements ProductAreaWithManager{
    protected int id;
    protected String name;
    protected float price;
    protected int quantityStock;
    protected int offer;

    abstract void addProduct();
    abstract void buyProduct(int quantity);

    public void addProduct(String information){
        System.out.println("Su talla es: " + information);
    }
}
