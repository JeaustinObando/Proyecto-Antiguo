public class Clothes extends Product{  
    // size and color protected attributes are added to the Clothes class inheriting from Product
    protected String size;
    protected String color;

    // constructor is added to the Clothes class inheriting from Product
    public Clothes(int i, String string, int j, int k, int l, String string2, String string3) {
        this.id = i;
        this.name = string;
        this.price = j;
        this.quantityStock = k;
        this.offer = l;
        this.size = string2;
        this.color = string3;
        addProduct();
    }

    // addProduct method is added to the Clothes class inheriting from Product
    @Override
    void addProduct() {
        System.out.println("Clothes added");
    }

    // agrega n cantidad de stock segun reciba como parametro al stock actual
    void buyProduct(int quantity) {
        this.quantityStock += quantity;
        System.out.println("Se han agregado " + quantity + " unidades");
        System.out.println("El stock actual de " + name + " es: " + quantityStock);
    }

    @Override
    public void getAreaName() {
        System.out.println("Clothing area");
    }

    @Override
    public void getManagerName() {
        System.out.println("Clothing manager: Maria Jose Espinoza");
    }
    
}
