public class LengShoppingList {
    protected Product[] products;
    protected LengClient client;
    // que cada producto tenga su cantidad comprada
    protected int[] purchasedAmount;

    public LengShoppingList(Product[] products, LengClient client, int[] purchasedAmount) {
        this.products = products;
        this.client = client;
        this.purchasedAmount = purchasedAmount;
        // purchased amount disminuye la cantidad de stock de cada producto de manera global
        for (int i = 0; i < products.length; i++) {
            products[i].quantityStock -= purchasedAmount[i];
            setPurchasedAmount(purchasedAmount);
        }
        System.out.println("La compra se ha realizado con exito\n");
    }

    public void setPurchasedAmount(int[] purchasedAmount) {
        this.purchasedAmount = purchasedAmount;
    }

    // crear bloque estatico para cuando se crea el carrito
    static {
        System.out.println("Shopping list created");
    }

    // dice si el carrito de compras esta vacio o no (boolean)
    public void isEmpty() {
        // si esta vacia imprime true
        if (products.length == 0) {
            System.out.println("true");
        } else {
            System.out.println("false");
        }
    }

    // Cuantos productos tiene la lista de compras
    public void countProducts() {
        if (products.length == 0) {
            System.out.println("La lista de compras esta vacia");
        } else {
            // sumar la cantidad total de productos
            int contFinalAmount = 0;
            for (int i = 0; i < purchasedAmount.length; i++) {
                contFinalAmount += purchasedAmount[i];
            }
            System.out.println("La lista de compras tiene tipos de " + products.length + " productos diferentes " + contFinalAmount + " productos en total");
        }
    }
    // el total de la compra: suma del valor de los productos * la cantidad a comprar * oferta
    // multiplicar por oferta solo si es mayor a 0
    public void totalPurchased() {
        int total = 0;
        for (int i = 0; i < products.length; i++) {
            if (products[i].offer > 0) {
                total += products[i].price * purchasedAmount[i] * products[i].offer;
            } else {
                total += products[i].price * purchasedAmount[i];
            }
        }
        System.out.println("El total de la compra es: " + total);
    }

    // incluir todos los datos asociados a ese producto, id, niombre, precio, cantidad en stock, oferta.
    // hacer cases para cada tipo de producto para imprimir sus datos tambien
    public void displayList() {
        
        System.out.println("+-------------------------------------------------+");
        System.out.println("|         Lista de Productos en Carrito        |");
        System.out.println("+-------------------------------------------------+");
    
        for (int i = 0; i < products.length; i++) {
            System.out.println("Producto " + (i + 1) + ":");
            System.out.println("ID:        " + products[i].id);
            System.out.println("Nombre:    " + products[i].name);
            System.out.println("Precio unitario:    $" + products[i].price);
            System.out.println("Cantidad comprada:     " + purchasedAmount[i]);
            System.out.println("Oferta:    " + (products[i].offer > 0 ? products[i].offer + "%" : "No hay oferta"));
    
            if (products[i] instanceof Clothes) {
                Clothes clothes = (Clothes) products[i];
                System.out.println("Tipo:      Ropa");
                System.out.println("Talla:     " + clothes.size);
                System.out.println("Color:     " + clothes.color);
            } else if (products[i] instanceof Electronics) {
                Electronics electronics = (Electronics) products[i];
                System.out.println("Tipo:      Electrónica");
                System.out.println("Marca:     " + electronics.brand);
                System.out.println("Modelo:    " + electronics.model);
            } else if (products[i] instanceof Games) {
                Games games = (Games) products[i];
                System.out.println("Tipo:      Videojuego");
                System.out.println("Plataforma: " + games.platform);
                System.out.println("Género:    " + games.genre);
            } else if (products[i] instanceof Shoes) {
                Shoes shoes = (Shoes) products[i];
                System.out.println("Tipo:      Zapatos");
                System.out.println("Talla:     " + shoes.size);
                System.out.println("Color:     " + shoes.color);
            }
    
            System.out.println("+-------------------------------------------------+");
        }
    }
    
}
