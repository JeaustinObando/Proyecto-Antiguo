#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define min(x, y) (((x) < (y)) ? (x) : (y))
#define max(x, y) (((x) > (y)) ? (x) : (y))

#define ROJO "\x1b[31m"
#define VERDE "\x1b[32m"
#define RESET "\x1b[0m"

#define FICHA_JUGADOR -1
#define FICHA_IA 1

#define PROFUNDIDAD 7

int conteo(int arreglo[4], int n) {
  int res = 0;
  for(int i = 0; i < 4; i++) if(arreglo[i] == n) res++;
  return res;
}

int suma(int arreglo[]) {
  int res = 0;
  for(int i = 0; i < sizeof(&arreglo); i++) res += arreglo[i];
  return res;
}

void imprimirTablero(int tablero[7][7]) {
  for(int i = 0; i < 7; i++) {

    printf("\n");

    for(int j = 0; j < 7; j++) {

      switch(tablero[i][j]) {

        case FICHA_JUGADOR:
        printf(VERDE "O " RESET);
        break;

        case 0:
        printf("O ");
        break;

        case FICHA_IA:
        printf(ROJO "O " RESET);
        break;
      }
    }
  }
  printf("\n-------------\n1 2 3 4 5 6 7\n");
}

int tableroLleno(int tablero[7][7]) {
  for(int j = 0; j < 7; j++) if(tablero[0][j] == 0) return 0;
  return 1;
}

int jugadaGanadora(int tablero[7][7], int ficha) {
  // Horizontal
  for(int i = 0; i < 7; i++) {
    for(int j = 0; j < 4; j++) {
      if(tablero[i][j] == ficha && tablero[i][j+1] == ficha && tablero[i][j+2] == ficha && tablero[i][j+3] == ficha) return 1;
    }
  }
  // Vertical
  for(int i = 0; i < 4; i++) {
    for(int j = 0; j < 7; j++) {
      if(tablero[i][j] == ficha && tablero[i+1][j] == ficha && tablero[i+2][j] == ficha && tablero[i+3][j] == ficha) return 1;
    }
  }
  // Diagonal principal
  for(int i = 0; i < 4; i++) {
    for(int j = 0; j < 4; j++) {
      if(tablero[i][j] == ficha && tablero[i+1][j+1] == ficha && tablero[i+2][j+2] == ficha && tablero[i+3][j+3] == ficha) return 1;
    }
  }
  // Diagonal contraria
  for(int i = 0; i < 4; i++) {
    for(int j = 3; j < 7; j++) {
      if(tablero[i][j] == ficha && tablero[i-1][j+1] == ficha && tablero[i-2][j+2] == ficha && tablero[i-3][j+3] == ficha) return 1;
    }
  }
  return 0;
}

int evaluarVentana(int ventana[4], int ficha) {
  int fichaContraria, puntaje = 0;
  if(ficha == FICHA_JUGADOR) fichaContraria = FICHA_IA;

  if(conteo(ventana, ficha) == 4) puntaje += 1000;
  if(conteo(ventana, ficha) == 3) puntaje += 100;
  if(conteo(ventana, ficha) == 2) puntaje += 10;
  if(conteo(ventana, fichaContraria) == 3) puntaje -= 100;
  
  return puntaje;
}

int asignarPuntaje(int tablero[7][7], int ficha) {
  int puntaje = 0;
  // Horizontal
  for(int i = 0; i < 7; i++) {
    for(int j = 0; j < 4; j++) {
      int ventana[4] = {tablero[i][j], tablero[i][j+1], tablero[i][j+2], tablero[i][j+3]};
      puntaje += evaluarVentana(ventana, ficha);
    }
  }
  // Vertical
  for(int i = 0; i < 4; i++) {
    for(int j = 0; j < 7; j++) {
      int ventana[4] = {tablero[i][j], tablero[i+1][j], tablero[i+2][j], tablero[i+3][j]};
      puntaje += evaluarVentana(ventana, ficha);
    }
  }
  // Diagonal principal
  for(int i = 0; i < 4; i++) {
    for(int j = 0; j < 4; j++) {
      int ventana[4] = {tablero[i][j], tablero[i+1][j+1], tablero[i+2][j+2], tablero[i+3][j+3]};
      puntaje += evaluarVentana(ventana, ficha);
    }
  }
  // Diagonal contraria
  for(int i = 0; i < 4; i++) {
    for(int j = 3; j < 7; j++) {
      int ventana[4] = {tablero[i][j], tablero[i-1][j+1], tablero[i-2][j+2], tablero[i-3][j+3]};
      puntaje += evaluarVentana(ventana, ficha);
    }
  }
  return puntaje;
}

int casillasValidas(int tablero[7][7]) {
  int res = 0;
  for(int j = 0; j < 7; j++) if(tablero[0][j] == 0) res++;
  return res;
}

int getFila(int tablero[7][7], int col) {
  for(int i = 6; i > -1; i--) if(tablero[i][col] == 0) return i;
}

int minimax(int tablero[7][7], int profundidad, int alpha, int beta, int jugadorMaximizante) {
  int numCasillasValidas = casillasValidas(tablero);
  int casillasValidas[numCasillasValidas];

  int indice = 0;
  for(int j = 0; j < 7; j++) {
    if(indice >= numCasillasValidas) break;
    if(tablero[0][j] == 0) {
      casillasValidas[indice] = j;
      indice++;
    }
  }

  int esHoja = jugadaGanadora(tablero, FICHA_JUGADOR) || jugadaGanadora(tablero, FICHA_IA) || tableroLleno(tablero);

  if(profundidad == 0) return asignarPuntaje(tablero, FICHA_IA);

  if(esHoja) {
    if(jugadaGanadora(tablero, FICHA_IA)) return 1000000000;
    if(jugadaGanadora(tablero, FICHA_JUGADOR)) return -1000000000;
    return 0;
  }

  if(jugadorMaximizante) {
    int valor = -1000000000; // -inf
    int columna = 0;
    while(tablero[0][columna] != 0) columna++;

    for(int i = 0; i < numCasillasValidas; i++) {
      int col = casillasValidas[i];
      int fila = getFila(tablero, col);
      tablero[fila][col] = FICHA_IA;

      int nuevoPuntaje = minimax(tablero, profundidad--, alpha, beta, 0);

      if(nuevoPuntaje > valor) {
        valor = nuevoPuntaje;
        columna = col;
      }

      alpha = max(alpha, valor);
      if(alpha >= beta) break;
    }
    return valor;
  }
  else {
    int valor = 1000000000; // +inf
    int columna = 0;
    while(tablero[0][columna] != 0) columna++;

    for(int i = 0; i < numCasillasValidas; i++) {
      int col = casillasValidas[i];
      int fila = getFila(tablero, col);
      tablero[fila][col] = FICHA_JUGADOR;

      int nuevoPuntaje = minimax(tablero, profundidad--, alpha, beta, 1);

      if(nuevoPuntaje < valor) {
        valor = nuevoPuntaje;
        columna = col;
      }

      beta = min(beta, valor);
      if(alpha >= beta) break;
    }
    return valor;
  }
}

void jugadaIA(int tablero[7][7]) {
  int puntaje = -1000000000;
  int columna = 0;

  for(int j = 0; j < 7; j++) {
    if(tablero[0][j] != 0) continue;

    int fila = getFila(tablero, j);
    tablero[fila][j] = FICHA_IA;

    int puntajeTmp = minimax(tablero, PROFUNDIDAD, -1000000000, 1000000000, 1);

    if(puntajeTmp > puntaje) {
      puntaje = puntajeTmp;
      columna = j;
    }
    fila = getFila(tablero, j);
    tablero[fila][j] = 0;
  }
  int fila = getFila(tablero, columna);
  tablero[fila][columna] = FICHA_IA;
}

void jugadaAleatoria(int tablero[7][7]) {
  int jugada = rand() % 7;
  
  while(tablero[0][jugada] != 0) {
    jugada = rand() % 7;
  }
  
  int fila = getFila(tablero, jugada);
  tablero[fila][jugada] = FICHA_IA;
}

void jugadaJugador(int tablero[7][7]) {
  int fila, jugada = 0;

  while (jugada < 1 || jugada > 7 || tablero[0][jugada] != 0) {
    printf("\nDigite la columna: ");
    scanf("%d", &jugada);
  }

  jugada--;

  fila = getFila(tablero, jugada);
  tablero[fila][jugada] = FICHA_JUGADOR;
}

int main() {
  int tablero[7][7];

  for(int i = 0; i < 7; i++) {
    for(int j = 0; j < 7; j++) tablero[i][j] = 0;
  }

  srand(time(0));
  int jugador = rand() % 2 + 1;
  
  for(int turno = 0; turno < 49 && !jugadaGanadora(tablero, FICHA_JUGADOR) && !jugadaGanadora(tablero, FICHA_IA); turno++) {
    switch((jugador + turno) % 2) {
      case 0:
      //jugadaIA(tablero);
      jugadaAleatoria(tablero);
      break;

      default: // case 1
      imprimirTablero(tablero);
      jugadaJugador(tablero);
      break;
    }
  }
  
  imprimirTablero(tablero);

  if(jugadaGanadora(tablero, FICHA_JUGADOR)) printf("\nGanó el jugador :D\n");
  else if(jugadaGanadora(tablero, FICHA_IA)) printf("\nGanó la máquina :c\n");
  else printf("\nEmpate :v\n");
}
